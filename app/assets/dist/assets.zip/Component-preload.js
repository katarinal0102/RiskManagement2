//@ui5-bundle RiskManagement2/Component-preload.js
sap.ui.require.preload({
	"RiskManagement2/manifest.json":'{"_version":"1.49.0","sap.app":{"id":"RiskManagement2","applicationVersion":{"version":"1.0.0"},"type":"application","title":"","description":"A simple CAP project.","i18n":"i18n/i18n.properties","crossNavigation":{"inbounds":{"riskmanagement2.risks-display":{"semanticObject":"riskmanagement2.risks","action":"display","signature":{"parameters":{},"additionalParameters":"allowed"}}}}},"sap.cloud":{"public":true,"service":"RiskManagement2.service"},"sap.ui5":{"flexBundle":false}}'
});
//# sourceMappingURL=Component-preload.js.map
